<?php

$ah_custom_image_slider_1     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-1', true);
$ah_custom_image_slider_1_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-1', true);
$slider1                      = attachment_url_to_postid($ah_custom_image_slider_1_alt);
$ah_custom_image_slider_1_alt = get_post_meta ( $slider1, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_2     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-2', true);
$ah_custom_image_slider_2_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-2', true);
$slider2                      = attachment_url_to_postid($ah_custom_image_slider_2_alt);
$ah_custom_image_slider_2_alt = get_post_meta ( $slider2, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_3     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-3', true);
$ah_custom_image_slider_3_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-3', true);
$slider3                      = attachment_url_to_postid($ah_custom_image_slider_3_alt);
$ah_custom_image_slider_3_alt = get_post_meta ( $slider3, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_4     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-4', true);
$ah_custom_image_slider_4_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-4', true);
$slider4                      = attachment_url_to_postid($ah_custom_image_slider_4_alt);
$ah_custom_image_slider_4_alt = get_post_meta ( $slider4, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_5     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-5', true);
$ah_custom_image_slider_5_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-5', true);
$slider5                      = attachment_url_to_postid($ah_custom_image_slider_5_alt);
$ah_custom_image_slider_5_alt = get_post_meta ( $slider5, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_6     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-6', true);
$ah_custom_image_slider_6_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-6', true);
$slider6                      = attachment_url_to_postid($ah_custom_image_slider_6_alt);
$ah_custom_image_slider_6_alt = get_post_meta ( $slider6, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_7     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-7', true);
$ah_custom_image_slider_7_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-7', true);
$slider7                      = attachment_url_to_postid($ah_custom_image_slider_7_alt);
$ah_custom_image_slider_7_alt = get_post_meta ( $slider7, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_8     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-8', true);
$ah_custom_image_slider_8_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-8', true);
$slider8                      = attachment_url_to_postid($ah_custom_image_slider_8_alt);
$ah_custom_image_slider_8_alt = get_post_meta ( $slider8, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_9     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-9', true);
$ah_custom_image_slider_9_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-9', true);
$slider9                      = attachment_url_to_postid($ah_custom_image_slider_9_alt);
$ah_custom_image_slider_9_alt = get_post_meta ( $slider9, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_10     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-10', true);
$ah_custom_image_slider_10_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-10', true);
$slider10                      = attachment_url_to_postid($ah_custom_image_slider_10_alt);
$ah_custom_image_slider_10_alt = get_post_meta ( $slider10, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_11     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-11', true);
$ah_custom_image_slider_11_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-11', true);
$slider11                      = attachment_url_to_postid($ah_custom_image_slider_11_alt);
$ah_custom_image_slider_11_alt = get_post_meta ( $slider11, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_12     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-12', true);
$ah_custom_image_slider_12_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-12', true);
$slider12                      = attachment_url_to_postid($ah_custom_image_slider_12_alt);
$ah_custom_image_slider_12_alt = get_post_meta ( $slider12, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_13     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-13', true);
$ah_custom_image_slider_13_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-13', true);
$slider13                      = attachment_url_to_postid($ah_custom_image_slider_13_alt);
$ah_custom_image_slider_13_alt = get_post_meta ( $slider13, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_14     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-14', true);
$ah_custom_image_slider_14_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-14', true);
$slider14                      = attachment_url_to_postid($ah_custom_image_slider_14_alt);
$ah_custom_image_slider_14_alt = get_post_meta ( $slider14, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_15     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-15', true);
$ah_custom_image_slider_15_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-15', true);
$slider15                      = attachment_url_to_postid($ah_custom_image_slider_15_alt);
$ah_custom_image_slider_15_alt = get_post_meta ( $slider15, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_16     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-16', true);
$ah_custom_image_slider_16_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-16', true);
$slider16                      = attachment_url_to_postid($ah_custom_image_slider_16_alt);
$ah_custom_image_slider_16_alt = get_post_meta ( $slider16, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_17     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-17', true);
$ah_custom_image_slider_17_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-17', true);
$slider17                      = attachment_url_to_postid($ah_custom_image_slider_17_alt);
$ah_custom_image_slider_17_alt = get_post_meta ( $slider17, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_18     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-18', true);
$ah_custom_image_slider_18_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-18', true);
$slider18                      = attachment_url_to_postid($ah_custom_image_slider_18_alt);
$ah_custom_image_slider_18_alt = get_post_meta ( $slider18, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_19     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-19', true);
$ah_custom_image_slider_19_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-19', true);
$slider19                      = attachment_url_to_postid($ah_custom_image_slider_19_alt);
$ah_custom_image_slider_19_alt = get_post_meta ( $slider19, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_20     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-20', true);
$ah_custom_image_slider_20_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-20', true);
$slider20                      = attachment_url_to_postid($ah_custom_image_slider_20_alt);
$ah_custom_image_slider_20_alt = get_post_meta ( $slider20, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_21     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-21', true);
$ah_custom_image_slider_21_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-21', true);
$slider21                      = attachment_url_to_postid($ah_custom_image_slider_21_alt);
$ah_custom_image_slider_21_alt = get_post_meta ( $slider21, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_22     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-22', true);
$ah_custom_image_slider_22_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-22', true);
$slider22                      = attachment_url_to_postid($ah_custom_image_slider_22_alt);
$ah_custom_image_slider_22_alt = get_post_meta ( $slider22, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_23     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-23', true);
$ah_custom_image_slider_23_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-23', true);
$slider23                      = attachment_url_to_postid($ah_custom_image_slider_23_alt);
$ah_custom_image_slider_23_alt = get_post_meta ( $slider23, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_24     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-24', true);
$ah_custom_image_slider_24_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-24', true);
$slider24                      = attachment_url_to_postid($ah_custom_image_slider_24_alt);
$ah_custom_image_slider_24_alt = get_post_meta ( $slider24, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_25     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-25', true);
$ah_custom_image_slider_25_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-25', true);
$slider25                      = attachment_url_to_postid($ah_custom_image_slider_25_alt);
$ah_custom_image_slider_25_alt = get_post_meta ( $slider25, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_26     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-26', true);
$ah_custom_image_slider_26_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-26', true);
$slider26                      = attachment_url_to_postid($ah_custom_image_slider_26_alt);
$ah_custom_image_slider_26_alt = get_post_meta ( $slider26, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_27     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-27', true);
$ah_custom_image_slider_27_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-27', true);
$slider27                      = attachment_url_to_postid($ah_custom_image_slider_27_alt);
$ah_custom_image_slider_27_alt = get_post_meta ( $slider27, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_28     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-28', true);
$ah_custom_image_slider_28_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-28', true);
$slider28                      = attachment_url_to_postid($ah_custom_image_slider_28_alt);
$ah_custom_image_slider_28_alt = get_post_meta ( $slider28, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_29     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-29', true);
$ah_custom_image_slider_29_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-29', true);
$slider29                      = attachment_url_to_postid($ah_custom_image_slider_29_alt);
$ah_custom_image_slider_29_alt = get_post_meta ( $slider29, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_30     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-30', true);
$ah_custom_image_slider_30_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-30', true);
$slider30                      = attachment_url_to_postid($ah_custom_image_slider_30_alt);
$ah_custom_image_slider_30_alt = get_post_meta ( $slider30, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_31     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-31', true);
$ah_custom_image_slider_31_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-31', true);
$slider31                      = attachment_url_to_postid($ah_custom_image_slider_31_alt);
$ah_custom_image_slider_31_alt = get_post_meta ( $slider31, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_32     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-32', true);
$ah_custom_image_slider_32_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-32', true);
$slider32                      = attachment_url_to_postid($ah_custom_image_slider_32_alt);
$ah_custom_image_slider_32_alt = get_post_meta ( $slider32, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_33     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-33', true);
$ah_custom_image_slider_33_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-33', true);
$slider33                      = attachment_url_to_postid($ah_custom_image_slider_33_alt);
$ah_custom_image_slider_33_alt = get_post_meta ( $slider33, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_34     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-34', true);
$ah_custom_image_slider_34_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-34', true);
$slider34                      = attachment_url_to_postid($ah_custom_image_slider_34_alt);
$ah_custom_image_slider_34_alt = get_post_meta ( $slider34, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_35     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-35', true);
$ah_custom_image_slider_35_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-35', true);
$slider35                      = attachment_url_to_postid($ah_custom_image_slider_35_alt);
$ah_custom_image_slider_35_alt = get_post_meta ( $slider35, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_36     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-36', true);
$ah_custom_image_slider_36_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-36', true);
$slider36                      = attachment_url_to_postid($ah_custom_image_slider_36_alt);
$ah_custom_image_slider_36_alt = get_post_meta ( $slider36, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_37     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-37', true);
$ah_custom_image_slider_37_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-37', true);
$slider37                      = attachment_url_to_postid($ah_custom_image_slider_37_alt);
$ah_custom_image_slider_37_alt = get_post_meta ( $slider37, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_38     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-38', true);
$ah_custom_image_slider_38_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-38', true);
$slider38                      = attachment_url_to_postid($ah_custom_image_slider_38_alt);
$ah_custom_image_slider_38_alt = get_post_meta ( $slider38, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_39     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-39', true);
$ah_custom_image_slider_39_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-39', true);
$slider39                      = attachment_url_to_postid($ah_custom_image_slider_39_alt);
$ah_custom_image_slider_39_alt = get_post_meta ( $slider39, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_40     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-40', true);
$ah_custom_image_slider_40_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-40', true);
$slider40                      = attachment_url_to_postid($ah_custom_image_slider_40_alt);
$ah_custom_image_slider_40_alt = get_post_meta ( $slider40, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_41     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-41', true);
$ah_custom_image_slider_41_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-41', true);
$slider41                      = attachment_url_to_postid($ah_custom_image_slider_41_alt);
$ah_custom_image_slider_41_alt = get_post_meta ( $slider41, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_42     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-42', true);
$ah_custom_image_slider_42_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-42', true);
$slider42                      = attachment_url_to_postid($ah_custom_image_slider_42_alt);
$ah_custom_image_slider_42_alt = get_post_meta ( $slider42, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_43     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-43', true);
$ah_custom_image_slider_43_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-43', true);
$slider43                      = attachment_url_to_postid($ah_custom_image_slider_43_alt);
$ah_custom_image_slider_43_alt = get_post_meta ( $slider43, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_44     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-44', true);
$ah_custom_image_slider_44_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-44', true);
$slider44                      = attachment_url_to_postid($ah_custom_image_slider_44_alt);
$ah_custom_image_slider_44_alt = get_post_meta ( $slider44, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_45     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-45', true);
$ah_custom_image_slider_45_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-45', true);
$slider45                      = attachment_url_to_postid($ah_custom_image_slider_45_alt);
$ah_custom_image_slider_45_alt = get_post_meta ( $slider45, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_46     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-46', true);
$ah_custom_image_slider_46_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-46', true);
$slider46                      = attachment_url_to_postid($ah_custom_image_slider_46_alt);
$ah_custom_image_slider_46_alt = get_post_meta ( $slider46, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_47     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-47', true);
$ah_custom_image_slider_47_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-47', true);
$slider47                      = attachment_url_to_postid($ah_custom_image_slider_47_alt);
$ah_custom_image_slider_47_alt = get_post_meta ( $slider47, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_48     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-48', true);
$ah_custom_image_slider_48_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-48', true);
$slider48                      = attachment_url_to_postid($ah_custom_image_slider_48_alt);
$ah_custom_image_slider_48_alt = get_post_meta ( $slider48, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_49     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-49', true);
$ah_custom_image_slider_49_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-49', true);
$slider49                      = attachment_url_to_postid($ah_custom_image_slider_49_alt);
$ah_custom_image_slider_49_alt = get_post_meta ( $slider49, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_50     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-50', true);
$ah_custom_image_slider_50_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-50', true);
$slider50                      = attachment_url_to_postid($ah_custom_image_slider_50_alt);
$ah_custom_image_slider_50_alt = get_post_meta ( $slider50, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_51     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-51', true);
$ah_custom_image_slider_51_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-51', true);
$slider51                      = attachment_url_to_postid($ah_custom_image_slider_51_alt);
$ah_custom_image_slider_51_alt = get_post_meta ( $slider51, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_52     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-52', true);
$ah_custom_image_slider_52_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-52', true);
$slider52                      = attachment_url_to_postid($ah_custom_image_slider_52_alt);
$ah_custom_image_slider_52_alt = get_post_meta ( $slider52, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_53     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-53', true);
$ah_custom_image_slider_53_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-53', true);
$slider53                      = attachment_url_to_postid($ah_custom_image_slider_53_alt);
$ah_custom_image_slider_53_alt = get_post_meta ( $slider53, '_wp_attachment_image_alt', true );

$ah_custom_image_slider_54     = get_post_meta(get_the_ID(), 'ah-custom-image-slider-54', true);
$ah_custom_image_slider_54_alt = get_post_meta(get_the_ID(), 'ah-custom-image-slider-54', true);
$slider54                      = attachment_url_to_postid($ah_custom_image_slider_54_alt);
$ah_custom_image_slider_54_alt = get_post_meta ( $slider54, '_wp_attachment_image_alt', true );